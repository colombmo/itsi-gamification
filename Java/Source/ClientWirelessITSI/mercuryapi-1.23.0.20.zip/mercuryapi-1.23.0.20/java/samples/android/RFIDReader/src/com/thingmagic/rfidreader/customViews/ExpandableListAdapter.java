package com.thingmagic.rfidreader.customViews;

import java.util.ArrayList;

import com.thingmagic.rfidreader.R;
import com.thingmagic.rfidreader.R.id;
import com.thingmagic.rfidreader.R.layout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

public class ExpandableListAdapter extends BaseExpandableListAdapter {

	private Context context;
	private String[] groups;
	private ArrayList<View> children;

	public ExpandableListAdapter(Context context, String[] groups,
			ArrayList<View> children) {
		this.context = context;
		this.groups = groups;
		this.children = children;
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {	
		return children.get(groupPosition);
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		try {
			convertView = (View) getChild(groupPosition, childPosition);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return convertView;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return 1;
	}

	@Override
	public Object getGroup(int groupPosition) {
		return groups[groupPosition];
	}

	@Override
	public int getGroupCount() {
		return groups.length;
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		String groupName = (String) getGroup(groupPosition);
		if (convertView == null) {
			LayoutInflater infalInflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = infalInflater.inflate(R.layout.group_layout, null);
		}
		TextView groupView = (TextView) convertView.findViewById(R.id.group);
		groupView.setText(groupName);
		return convertView;
	}

	@Override
	public boolean hasStableIds() {
		return true;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return false;
	}

}
